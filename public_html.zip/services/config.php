<?php 
    //Definimos parametros de la bbdd
 define("SERVIDOR","localhost");
 define("USUARIO","id17875467_user_db");
 define("PASSWORD","A>v4Yh/bLh&)8Q#2");
 define("BD","id17875467_second_bar");

 # HTID:18672244: DO NOT REMOVE OR MODIFY THIS LINE AND THE LINES BELOW
