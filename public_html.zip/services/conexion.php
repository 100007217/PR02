<?php
$servername = "localhost";
$username = "id17875467_user_db";
$password = "A>v4Yh/bLh&)8Q#2";
$database = "id17875467_second_bar";
 
 try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {    
    echo "Connection failed: " . $e->getMessage();
    }
?>