<?php 
    //Definimos parametros de la bbdd
 define("SERVIDOR","localhost");
 define("USUARIO","root");
 define("PASSWORD","admira123");
 define("BD","bd_bar");

 # HTID:18672244: DO NOT REMOVE OR MODIFY THIS LINE AND THE LINES BELOW
